<?php

  // Namespace
  namespace Inisev\Subs;

  // Disallow direct access
  if (!defined('ABSPATH')) exit;

?>

<div class="ci-right-part ci-hidden-for-upgrade">
  <img src="<?php $this->_asset('/projects/usm/imgs/background-icons.png'); ?>" class="ci-main-image ci-background-icons">
</div>
