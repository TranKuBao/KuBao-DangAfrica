<?php

  // Namespace
  namespace BMI\Plugin\Dashboard;

  // Exit on direct access
  if (!defined('ABSPATH')) exit;

?>

<div class="mm mtl mbl lh30">
  <a href="#" class="btn save-btn"><?php _e("Save", 'backup-backup'); ?></a>
</div>

<div class="mm center f20 mb">
  <a href="#" class="text-muted close-chapters nodec"><?php _e("Collapse this chapter", 'backup-backup'); ?></a>
</div>
<div class="mbll"></div>
