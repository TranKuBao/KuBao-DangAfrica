<?php

  // Namespace
  namespace BMI\Plugin\Dashboard;

  // Exit on direct access
  if (!defined('ABSPATH')) exit;

?>

<a href="#" class="bmi-modal-opener" data-modal="test-modal">Open test modal</a>

<div class="bmi-modal" id="test-modal">

  <div class="bmi-modal-wrapper" style="max-width: 564px; max-width: min(564px, 80vw);">
    <a href="#" class="bmi-modal-close">×</a>
    <div class="bmi-modal-content">

      <div class="mm60 f26 medium">We noticed:</div>


    </div>
  </div>

</div>
