<?php

// Exit on direct access
if (!defined('ABSPATH')) {
  exit;
}

?>

<jdiv class="label_e50 _bottom_ea7 notranslate" id="bmi_support_chat" style="background: linear-gradient(95deg, rgb(47, 50, 74) 20%, rgb(66, 72, 103) 80%);right: 30px;bottom: 0px;width: 310px;">
<jdiv class="hoverl_bc6"></jdiv>
<jdiv class="text_468 _noAd_b4d contentTransitionWrap_c73" style="font-size: 15px;font-family: Arial, Arial;font-style: normal;color: rgb(240, 241, 241);position: absolute;top: 8px;line-height: 13px;">
  <span>Connect with support (click to load)</span><br>
  <span style="color: #eee;font-size: 10px;">
    This will establish connection to the chat servers
  </span>
</jdiv>
  <jdiv class="leafCont_180">
    <jdiv class="leaf_2cc _bottom_afb">
      <jdiv class="cssLeaf_464"></jdiv>
  </jdiv>
</jdiv>
</jdiv>
