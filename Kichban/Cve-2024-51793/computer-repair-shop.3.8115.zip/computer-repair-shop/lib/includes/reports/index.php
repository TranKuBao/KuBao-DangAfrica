<?php
defined( 'ABSPATH' ) || exit;
	//Silence is good