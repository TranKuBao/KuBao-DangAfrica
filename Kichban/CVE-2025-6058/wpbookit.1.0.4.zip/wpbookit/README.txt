=== WPBookit ===
Contributors: iqonicdesign
Tags: free appointment booking wordpress plugin, free wordpress reservation plugin,  free booking system wordpress,  free reservation plugin, free booking system wordpress
Requires at least: 3.0.1
Tested up to: 6.8.1
Requires PHP: 8.0
Stable tag: 1.0.4
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

WPBookit is a free WordPress booking plugin that simplifies  seamless scheduling, custom calendars and global accessibility.

## Description

[Get Flat 30% OFF on WPBookit Pro at this Year End Thank You Sale!](https://wpbookit.com/)

Streamline your appointment booking process with WPBookit, the ultimate free appointment booking WordPress plugin. Ideal for businesses of all sizes, WPBookit offers a comprehensive suite of features designed to simplify scheduling, enhance user experience, and boost productivity.

### Features:
- Revenue Chart Report: Gain valuable insights into your earnings with detailed revenue charts.
- Booking Calendar/List View: View and manage bookings effortlessly with both calendar and list views.
- Different Calendars for Different Services: Organize your services with separate calendars for each one.
- Custom Time Slots: Customize available time slots to fit your unique business hours and needs.
- Calendar-wise Unavailable Dates: Mark unavailable dates on individual calendars to avoid scheduling conflicts.
- Guest Users List: Maintain a list of guest users for easy reference and follow-up.
- Easy Email Template Editing: Customize email templates with ease for a personalized communication experience.
- Translation Ready: Cater to a global audience with translation-ready capabilities.

### Benefits:
- Efficient Scheduling: Simplify the booking process with intuitive calendar and list views, ensuring smooth management of appointments.
- Enhanced User Experience: Provide a seamless experience for both customers and staff with features like custom timeslots, email notifications.
- Virtual Consultations: Offer convenient telemedicine services with Zoom integration, expanding your reach and flexibility.
- Comprehensive Management: Keep track of guest users, manage multiple services, and generate detailed reports to optimize your business operations.
- Global Reach: Serve a diverse audience with translation-ready functionality, making your services accessible to users worldwide.

Elevate your appointment booking process with WPBookit - the free WordPress plugin designed to meet all your scheduling needs. **[WPBookit Pro](https://wpbookit.com) version is also available with advance featutes.**

== Frequently Asked Questions ==

= How many booking calendars can I create? =
There's no limit to the number of booking calendars you can create with WPBookit. You can set up as many calendars as needed for your different services and business needs.

= Can I customize email notifications? =
Yes, WPBookit comes with an easy email template editing system. You can customize notification templates for various events like new bookings, booking confirmations, and updates to match your brand's communication style.

= Do I get free updates? =
Yes, you'll receive free updates whenever we release new versions of WPBookit. All updates for the free version are automatically available through the WordPress plugin repository.

= Do I need coding knowledge to use WPBookit? =
No coding skills are required to use WPBookit. Our plugin is designed with a user-friendly interface that makes it easy for anyone to set up and manage their booking system, regardless of technical expertise.

= What payment methods are supported? =
The free version of WPBookit provides basic booking functionality. For advanced payment features, check out WPBookit Pro which offers enhanced payment capabilities.

= Can I create separate calendars for different services? =
Yes, WPBookit allows you to create different calendars for different services. This feature helps you organize your offerings more effectively and makes it easier for customers to book specific services.

= How do I add a booking calendar to my page? =
You can easily add booking calendars to any page or post using shortcodes. Simply copy the shortcode for your specific calendar and paste it where you want the booking form to appear on your website.

= Can I track my booking revenue? =
Yes, WPBookit includes a Revenue Chart Report feature that allows you to track and analyze your booking earnings over time, helping you monitor your business performance.

= How do I manage unavailable dates? =
WPBookit allows you to mark specific dates as unavailable on individual calendars. This is perfect for managing holidays, maintenance periods, or any other times when you're not accepting bookings.

= Is the plugin translation-ready? =
Yes, WPBookit is fully translation-ready, allowing you to serve customers in multiple languages and expand your business globally.

= Can I customize time slots for bookings? =
Yes, you can create custom time slots that match your business hours and scheduling preferences. This flexibility allows you to set up booking times that work best for your business.

== Installation ==
= Installation from within WordPress =
1. Visit **Plugins > Add New**
2. Search for **WPBookit**
3. Install and activate the WPBookit plugin.

== Source Code ==
The original, non-minified source code for the JavaScript and CSS files used in this plugin can be found in the `core/admin/assets/src` directory of the plugin folder.

== External Services ==
WPBookit interacts with external services to enhance functionality and provide accurate data.

### Services Used:
1. **ipapi.co** (https://ipapi.co/)
   - **Purpose**: Used for geolocation purposes to automatically determine and set the user's country based on their IP address.
   - **Terms of Use**: [ipapi.co Terms of Service](https://ipapi.co/terms/)
   - **Privacy Policy**: [ipapi.co Privacy Policy](https://ipapi.co/privacy/)

2. **Google Fonts** (https://fonts.googleapis.com/)
   - **Purpose**: The plugin uses the "Plus Jakarta Sans" font, which is loaded from Google Fonts to enhance the visual appearance of the plugin.
   - **Terms of Use**: [Google Fonts Terms of Service](https://developers.google.com/fonts/terms)
   - **Privacy Policy**: [Google Fonts Privacy Policy](https://policies.google.com/privacy)

3. **Add to Calendar Pro API** (https://add-to-calendar-pro.com/)
   - **Purpose**: Used to add booking details directly to users' calendars.
   - **Terms of Use**: [Add to Calendar Pro Terms of Service](https://add-to-calendar-pro.com/terms/)
   - **Privacy Policy**: [Add to Calendar Pro Privacy Policy](https://add-to-calendar-pro.com/privacy-policy/)

By using WPBookit, you agree to the terms and conditions outlined by these external services.

== Changelog ==

= 1.0.4 - 14/06/2025 =
* [Fixed] Conflict With Wordpress new version 6.8.1.

= 1.0.1 - 27/12/2024 =
* [Fixed] Conflict With WPBookit Pro version.

= 1.0.0 - 18/12/2024 =
* Initial stable release