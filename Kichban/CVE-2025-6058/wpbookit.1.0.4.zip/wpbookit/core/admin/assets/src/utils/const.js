export const wpbookitPluginPath = {
    image : `${window?.wpbookit?.wpb_plugin_url}core/admin/assets/images/`
};