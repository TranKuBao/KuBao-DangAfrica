<?php
	defined( 'ABSPATH' ) || exit;
	//Silence is good

	require_once WC_COMPUTER_REPAIR_SHOP_DIR . 'lib' . DS . 'includes' . DS . 'theme_functions.php';
	require_once WC_COMPUTER_REPAIR_SHOP_DIR . 'lib' . DS . 'includes' . DS . 'main_page.php';
	require_once WC_COMPUTER_REPAIR_SHOP_DIR . 'lib' . DS . 'includes' . DS . 'wc_services.php';
	require_once WC_COMPUTER_REPAIR_SHOP_DIR . 'lib' . DS . 'includes' . DS . 'wc_products.php';
	require_once WC_COMPUTER_REPAIR_SHOP_DIR . 'lib' . DS . 'includes' . DS . 'wc_devices.php';
	require_once WC_COMPUTER_REPAIR_SHOP_DIR . 'lib' . DS . 'includes' . DS . 'wc_jobs.php';
	require_once WC_COMPUTER_REPAIR_SHOP_DIR . 'lib' . DS . 'includes' . DS . 'wc_clients.php';
	require_once WC_COMPUTER_REPAIR_SHOP_DIR . 'lib' . DS . 'includes' . DS . 'wc_payments.php';
	require_once WC_COMPUTER_REPAIR_SHOP_DIR . 'lib' . DS . 'includes' . DS . 'wc_reminder_logs.php';
	require_once WC_COMPUTER_REPAIR_SHOP_DIR . 'lib' . DS . 'includes' . DS . 'wc_technicians.php';
	require_once WC_COMPUTER_REPAIR_SHOP_DIR . 'lib' . DS . 'includes' . DS . 'wc_managers.php';
	require_once WC_COMPUTER_REPAIR_SHOP_DIR . 'lib' . DS . 'includes' . DS . 'wc_print_functionality.php';
	require_once WC_COMPUTER_REPAIR_SHOP_DIR . 'lib' . DS . 'includes' . DS . 'reports' . DS . 'load.php';
	require_once WC_COMPUTER_REPAIR_SHOP_DIR . 'lib' . DS . 'includes' . DS . 'wc_employees.php';
	require_once WC_COMPUTER_REPAIR_SHOP_DIR . 'lib' . DS . 'includes' . DS . 'wc_reports.php';
	require_once WC_COMPUTER_REPAIR_SHOP_DIR . 'lib' . DS . 'includes' . DS . 'currency_functions.php';