<?php

/**
 * Do not put custom translations here as they will be overwritten during plugin updates.
 *
 */